package com.choupangxia.view;

/**
 * @author sec
 * @version 1.0
 * @date 2020/1/1 10:33 PM
 **/
public interface View {

	interface BaseView{}

	interface DetailView extends BaseView {
	}

}

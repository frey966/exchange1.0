package com.choupangxia.entity;

/**
 * @author sec
 * @version 1.0
 * @date 2020/1/3 7:39 AM
 **/
public class ColorDetail {

	private double red;

	private double green;

	private double blue;


	public double getRed() {
		return red;
	}

	public void setRed(double red) {
		this.red = red;
	}

	public double getGreen() {
		return green;
	}

	public void setGreen(double green) {
		this.green = green;
	}

	public double getBlue() {
		return blue;
	}

	public void setBlue(double blue) {
		this.blue = blue;
	}
}

package com.secbro.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.secbro.model.Order;

import java.util.List;

/**
 * @author sec
 * @version 1.0
 * @date 2020/3/1 10:01 AM
 **/
public interface OrderMapper extends BaseMapper<Order> {

}

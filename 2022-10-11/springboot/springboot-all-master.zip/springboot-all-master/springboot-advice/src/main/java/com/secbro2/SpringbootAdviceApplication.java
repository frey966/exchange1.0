package com.secbro2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAdviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAdviceApplication.class, args);
	}

}

package com.secbro2.entity;

import lombok.Data;

/**
 * @author sec
 * @version 1.0
 * @date 2020/1/12 9:14 AM
 **/
@Data
public class Student {

	private String idNo;

	private String name;
}

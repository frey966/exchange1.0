package com.secbro2.springboothttps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHttpsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.secbro2.springbootjsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJspApplicationTests {

	@Test
	void contextLoads() {
	}

}

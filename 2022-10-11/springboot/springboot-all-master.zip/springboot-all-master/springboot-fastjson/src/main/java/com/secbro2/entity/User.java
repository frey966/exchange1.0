package com.secbro2.entity;

import lombok.Data;

/**
 * @author sec
 * @version 1.0
 * @date 2020/1/7 2:00 PM
 **/
@Data
public class User {

	private int userId;

	private String username;

}

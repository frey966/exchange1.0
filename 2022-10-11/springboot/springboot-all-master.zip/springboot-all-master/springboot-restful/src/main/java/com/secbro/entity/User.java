package com.secbro.entity;

import lombok.Data;

/**
 * @author sec
 * @version 1.0
 * @date 2020/2/19 10:32 AM
 **/
@Data
public class User {

	private Long id;

	private String username;
}

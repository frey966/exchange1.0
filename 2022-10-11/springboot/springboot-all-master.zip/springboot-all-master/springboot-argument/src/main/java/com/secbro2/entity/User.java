package com.secbro2.entity;

import lombok.Data;

/**
 * @author sec
 * @version 1.0
 * @date 2020/12/18
 **/
@Data
public class User {

    private Integer userId;

    private String name;
}

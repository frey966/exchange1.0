package com.secbro2.util;

/**
 * @author sec
 * @version 1.0
 * @date 2020/12/18
 **/
public class TokenUtil {

    public static Integer getUserIdByToken(String token){
        // TODO 伪代码，具体情况根据业务来实现。
        return 1;
    }
}

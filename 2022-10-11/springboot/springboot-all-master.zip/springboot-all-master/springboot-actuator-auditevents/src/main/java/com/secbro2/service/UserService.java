package com.secbro2.service;

import org.springframework.stereotype.Service;

/**
 * @author sec
 * @version 1.0
 * @date 2021/7/12
 **/
@Service
public class UserService {
}

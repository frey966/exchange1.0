package com.secbro2.db;

/**
 * @author sec
 * @version 1.0
 * @date 2019/12/26 3:54 PM
 **/
public interface DbConfigBean {

	void printInfo();
}

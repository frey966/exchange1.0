package com.secbro.redis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRedisLockApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRedisLockApplication.class, args);
	}

}

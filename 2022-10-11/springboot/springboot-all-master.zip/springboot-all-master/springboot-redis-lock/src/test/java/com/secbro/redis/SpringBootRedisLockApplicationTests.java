package com.secbro.redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRedisLockApplicationTests {

	@Test
	void contextLoads() {
	}

}

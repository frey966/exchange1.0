package com.zlp.utils;

/**
 * 缓存的key 常量
 */
public interface CacheConstants {

	/**
	 * 路由存放
	 */
	String ROUTE_KEY = "gateway_route_key";


}

package com.zlp.utils;

/** 
 * Reids常量
 * @date: 2020/12/30 16:13
 *
 */
public interface RedisConstants {


    /**
     *  用户缓存
     */
    String CACHE = "CACHE";




}

package com.zlp.entity;

import lombok.Data;

@Data
public class User {

    private String userName;
    private String address;
}

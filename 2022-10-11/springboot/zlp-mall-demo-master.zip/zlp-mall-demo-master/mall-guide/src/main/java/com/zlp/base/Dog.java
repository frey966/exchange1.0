package com.zlp.base;

public class Dog extends Animal {
    @Override
    void eat() {
        System.out.println("吃骨头");
    }

    public void work() {
        System.out.println("看家");
    }
}

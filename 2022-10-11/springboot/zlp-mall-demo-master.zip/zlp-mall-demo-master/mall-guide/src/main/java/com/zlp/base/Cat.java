package com.zlp.base;

public class Cat extends Animal {

    public void eat() {
        System.out.println("吃鱼");
    }
    public void work() {
        System.out.println("抓老鼠");
    }
}

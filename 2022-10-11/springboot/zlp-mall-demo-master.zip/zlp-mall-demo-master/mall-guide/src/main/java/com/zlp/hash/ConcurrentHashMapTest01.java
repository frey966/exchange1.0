package com.zlp.hash;

import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j(topic = "HashMapTest01")
public class ConcurrentHashMapTest01 {

    public static void main(String[] args) {

        ConcurrentHashMapDebug<String, Object> hashMap = new ConcurrentHashMapDebug<>();
        hashMap.put("k1","李健");
        hashMap.put("k2","周杰伦");
        hashMap.put("k3","科比");
//        high 高、low低
//        hashMap.remove("k3");
//
//        System.out.println(hashMap.get("key1"));
//
//        System.out.println(Integer.highestOneBit(17));

//        Green-valley

       hashMap.putAll(hashMap);



    }

}

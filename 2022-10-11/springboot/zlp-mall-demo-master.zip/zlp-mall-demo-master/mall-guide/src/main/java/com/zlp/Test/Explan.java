package com.zlp.Test;

public class Explan {

    final static String COLOR_TEST = "test";

    public static void main(String[] args) {
        // process
//        redo
        // media failure
        // Write-Ahead Logging
        // prepare
        // crash
        // crash-safe
        String abc = null;
        if (abc.equals(COLOR_TEST)) {
            System.out.println("true");
        } else {
            System.out.println("false");
        }
    }
}

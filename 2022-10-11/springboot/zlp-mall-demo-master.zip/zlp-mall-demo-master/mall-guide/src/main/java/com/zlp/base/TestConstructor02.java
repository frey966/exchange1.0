package com.zlp.base;

public class TestConstructor02 extends TestConstructor01 {

    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder();
    }

    @Override
    public String getAddress() {
        return super.getAddress();
    }

    @Override
    public String getUserName() {
        return super.getUserName();
    }

    public TestConstructor02(){

    }
}

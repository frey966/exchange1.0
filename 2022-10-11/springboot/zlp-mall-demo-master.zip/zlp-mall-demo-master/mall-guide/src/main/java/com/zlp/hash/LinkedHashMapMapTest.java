package com.zlp.hash;

import java.util.LinkedHashMap;

public class LinkedHashMapMapTest {

    public static void main(String[] args) {

        LinkedHashMap linkedHashMap = new LinkedHashMap<>(3);
        linkedHashMap.put("a","a");
        linkedHashMap.put("b","b");
        linkedHashMap.put("c","c");
        linkedHashMap.put("d","d");
//        Object a = linkedHashMap.get("a");
        for (Object o : linkedHashMap.entrySet()) {
            System.out.println(o);
        }

    }
}

 class LinekedLRU{

    volatile int size = 10;
    volatile int threslod = 6;

     static LinkedHashMap linkedHashMap;


     public void put(Object key,Object value){

         if (linkedHashMap == null || linkedHashMap.size() == 0){
             linkedHashMap = new LinkedHashMap(size);
         }

         if (linkedHashMap.size() >= threslod) {
             Object o = linkedHashMap.get(linkedHashMap.size() - 1);
             linkedHashMap.remove(o.getClass());
         }
         linkedHashMap.put(key,value);
     }

 }

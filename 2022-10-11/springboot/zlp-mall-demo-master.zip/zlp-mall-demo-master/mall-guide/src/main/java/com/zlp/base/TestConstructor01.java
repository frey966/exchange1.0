package com.zlp.base;

import lombok.Data;

@Data
public class TestConstructor01 {

    private String userName;
    private String address;

    public TestConstructor01(){

    }
}

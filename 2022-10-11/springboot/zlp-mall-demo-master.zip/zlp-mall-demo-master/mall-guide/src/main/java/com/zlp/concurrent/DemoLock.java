package com.zlp.concurrent;

public class DemoLock {

    private int state;
    private boolean flag;
}

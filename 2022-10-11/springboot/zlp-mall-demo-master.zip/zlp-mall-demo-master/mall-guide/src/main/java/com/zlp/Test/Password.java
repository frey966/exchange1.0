package com.zlp.Test;

import java.util.Base64;

public class Password {

    public static void main(String[] args) {

        String password = "123456";
        System.out.println(Base64.getEncoder().encodeToString(password.getBytes()));
    }
}

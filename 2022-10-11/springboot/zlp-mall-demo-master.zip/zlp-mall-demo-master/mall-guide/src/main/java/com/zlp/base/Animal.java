package com.zlp.base;

public abstract class Animal {

    abstract void eat();
}

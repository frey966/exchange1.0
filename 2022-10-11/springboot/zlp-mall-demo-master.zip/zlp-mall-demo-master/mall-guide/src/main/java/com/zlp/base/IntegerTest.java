package com.zlp.base;

public class IntegerTest {

    public static void main(String[] args) {
//        Integer i = new Integer(100);
//        Integer j = new Integer(100);
//        System.out.println(i == j); //false

        System.out.println("============================");
        Integer i = new Integer(100);
        int j = 100;
        System.out.println(i == j); //true
    }

    public static void Test1(String str1){
        Test2(str1);
    }

    public final static void Test2(String str1){

    }
}

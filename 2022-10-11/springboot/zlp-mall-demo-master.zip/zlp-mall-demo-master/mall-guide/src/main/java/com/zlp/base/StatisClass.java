package com.zlp.base;

import java.sql.SQLOutput;

public class StatisClass {

    private static String userName = "刘敏红";
    private static String address = "刘敏红";

    public static void main(String[] args) {
        getMethod2();
    }


    public static void getMethod(){
        System.out.println(userName);
//        getMethod2();
    }

    public static void getMethod2(){
        System.out.println(address.hashCode());
        getMethod();
    }
}

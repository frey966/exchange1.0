package com.zlp.test;

public class Runables {

    public static void main(String[] args) {
        System.out.println("main线程的名称===》"+Thread.currentThread().getName());
        new Thread(() ->{
            System.out.println(" thread 线程的名称===》"+Thread.currentThread().getName());
        }).start();
    }
}

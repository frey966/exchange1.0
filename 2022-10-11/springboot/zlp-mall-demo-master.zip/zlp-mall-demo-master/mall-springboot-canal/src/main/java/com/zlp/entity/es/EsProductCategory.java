package com.zlp.entity.es;

import lombok.Data;

@Data
public class EsProductCategory 
{
	private Long cateId;
	
	private Long cateId1;
	
	private Long cateId2;
}

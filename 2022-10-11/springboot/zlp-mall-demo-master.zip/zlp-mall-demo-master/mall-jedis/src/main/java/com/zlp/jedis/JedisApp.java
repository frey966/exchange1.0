package com.zlp.jedis;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JedisApp {

    public static void main(String[] args) {
        SpringApplication.run(JedisApp.class,args);
    }
}

package com.zlp.utils;

public class MyException extends Exception{


}

package com.zlp.test.MsgTest;

public class Msg {

    public static void main(String[] args) {
        String tempMsg = "{1}xxx{2}2232,{3}323";
        System.out.println(getMsgContent(tempMsg, "zou", "li", "ping"));
    }

    public static String getMsgContent(String tempMsg,String...ars){
        for (int i = 0; i < ars.length; i++) {
            tempMsg = tempMsg.replace("{"+(i+1)+"}",ars[i]);
        }
        return tempMsg;
    }
}

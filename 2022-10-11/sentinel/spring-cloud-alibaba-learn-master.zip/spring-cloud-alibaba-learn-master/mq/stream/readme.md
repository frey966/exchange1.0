# 说明
stream-kafka和stream-rocketmq: 除了使用依赖和yaml文件配置不同，其他一致

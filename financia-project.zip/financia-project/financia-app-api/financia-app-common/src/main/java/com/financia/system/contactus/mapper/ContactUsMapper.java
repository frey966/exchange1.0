package com.financia.system.contactus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.common.ContactUs;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Yezi
 */
@Mapper
public interface ContactUsMapper extends BaseMapper<ContactUs> {
}

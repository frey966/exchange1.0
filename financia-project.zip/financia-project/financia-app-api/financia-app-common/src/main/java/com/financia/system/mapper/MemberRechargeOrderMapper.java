package com.financia.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.exchange.MemberRechargeOrder;
import org.apache.ibatis.annotations.Mapper;

/**
 *
 *
 * @author dalong
 * @email xxxxxx@qq.com
 * @date 2022-08-07 21:11:10
 */
@Mapper
public interface MemberRechargeOrderMapper extends BaseMapper<MemberRechargeOrder> {

}

package com.financia.system.aboutus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.common.AboutUs;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Yezu
 */
@Mapper
public interface AboutUsMapper extends BaseMapper<AboutUs> {
}

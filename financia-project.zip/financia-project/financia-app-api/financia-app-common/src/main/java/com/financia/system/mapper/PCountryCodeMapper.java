package com.financia.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.common.PCountryCode;
import org.apache.ibatis.annotations.Mapper;

/**
 *
 *
 * @author dalong
 * @email xxxxxx@qq.com
 * @date 2022-07-27 21:13:55
 */
@Mapper
public interface PCountryCodeMapper extends BaseMapper<PCountryCode> {

}

package com.financia.system.compliance.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.common.PCompliance;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ComplianceMapper extends BaseMapper<PCompliance> {
}

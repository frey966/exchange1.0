package com.financia.system.contactus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.common.ContactUs;

public interface ContactUsService extends IService<ContactUs> {
}

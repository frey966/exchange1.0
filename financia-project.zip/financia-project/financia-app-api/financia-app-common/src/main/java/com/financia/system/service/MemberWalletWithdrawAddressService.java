package com.financia.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.exchange.MemberWalletWithdrawAddress;

/**
 * 会员提现公链
 *
 * @author dalong
 * @email xxxxxx@qq.com
 * @date 2022-08-12 23:28:49
 */
public interface MemberWalletWithdrawAddressService extends IService<MemberWalletWithdrawAddress> {

//    PageUtils queryPage(Map<String, Object> params);
}


package com.financia.system.compliance.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.common.PCompliance;

public interface ComplianceSercice extends IService<PCompliance> {
}

package com.financia.system.crypto.tron.common.exception;

public class CancelException extends TronException {

  public CancelException() {
    super();
  }

  public CancelException(String message) {
    super(message);
  }

}

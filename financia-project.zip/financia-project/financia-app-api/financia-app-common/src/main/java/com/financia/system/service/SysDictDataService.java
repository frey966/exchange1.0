package com.financia.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.system.SysDictData;


/**
 * 字典 业务层
 * 
 * @author ruoyi
 */
public interface SysDictDataService extends IService<SysDictData>
{

}

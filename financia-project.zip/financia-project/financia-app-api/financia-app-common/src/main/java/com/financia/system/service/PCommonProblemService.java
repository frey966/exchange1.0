package com.financia.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.common.PCommonProblem;

/**
 * 常见Service接口
 *
 * @author putao
 * @date 2022-07-13
 */
public interface PCommonProblemService extends IService<PCommonProblem> {
}

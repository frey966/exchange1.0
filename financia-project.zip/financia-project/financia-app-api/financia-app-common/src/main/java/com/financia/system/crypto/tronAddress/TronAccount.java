package com.financia.system.crypto.tronAddress;


import lombok.Data;


@Data
public class TronAccount{


	private String baseAddress;


	private String hexAddress;


	private String privateKey;

}

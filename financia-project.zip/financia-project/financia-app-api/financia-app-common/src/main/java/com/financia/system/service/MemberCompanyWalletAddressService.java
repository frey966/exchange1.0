package com.financia.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.exchange.MemberCompanyWalletAddress;

/**
 * 公链钱包
 *
 * @author dalong
 * @email xxxxxx@qq.com
 * @date 2022-08-23 21:01:00
 */
public interface MemberCompanyWalletAddressService extends IService<MemberCompanyWalletAddress> {

}


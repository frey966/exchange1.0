package com.financia.system.util;

public class Test {
    public static void main(String[] args) {

    }
}

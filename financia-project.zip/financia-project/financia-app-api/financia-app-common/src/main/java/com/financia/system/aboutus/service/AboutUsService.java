package com.financia.system.aboutus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.common.AboutUs;

/**
 * @author Yezu
 */
public interface AboutUsService extends IService<AboutUs> {
}

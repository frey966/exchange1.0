package com.financia.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.common.PFeedbackQuestions;

public interface PFeedbackQuestionsService extends IService<PFeedbackQuestions> {
}

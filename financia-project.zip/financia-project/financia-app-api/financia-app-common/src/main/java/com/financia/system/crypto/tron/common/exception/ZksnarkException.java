package com.financia.system.crypto.tron.common.exception;

public class ZksnarkException extends TronException {

  public ZksnarkException() {
    super();
  }

  public ZksnarkException(String message) {
    super(message);
  }
}

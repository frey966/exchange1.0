package com.financia.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.common.PInformNotice;

/**
 * 公共-通知表
 *
 * @author dalong
 * @email xxxxxx@qq.com
 * @date 2022-09-18 19:35:54
 */
public interface PInformNoticeService extends IService<PInformNotice> {

//    PageUtils queryPage(Map<String, Object> params);
}


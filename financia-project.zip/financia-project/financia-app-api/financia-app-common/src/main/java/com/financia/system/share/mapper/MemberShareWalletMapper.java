package com.financia.system.share.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.common.MemberShare;
import org.apache.ibatis.annotations.Mapper;


/**
 * @author Yezi
 */
@Mapper
public interface MemberShareWalletMapper extends BaseMapper<MemberShare> {
}

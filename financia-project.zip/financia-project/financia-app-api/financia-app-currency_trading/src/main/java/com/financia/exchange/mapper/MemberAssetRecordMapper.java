package com.financia.exchange.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.swap.MemberAssetRecord;

public interface MemberAssetRecordMapper extends BaseMapper<MemberAssetRecord> {
}

package com.financia.exchange.dto;

public enum ContractOptionOrderDirection {
    BUY(0, "看涨"),
    SELL(1, "看跌");

    ContractOptionOrderDirection(int number, String description) {
        this.code = number;
        this.description = description;
    }
    private int code;
    private String description;
    public int getCode() {
        return code;
    }
    public String getDescription() {
        return description;
    }
}

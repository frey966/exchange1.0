package com.financia.exchange.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.trading.ExchangeTrade;
import org.springframework.stereotype.Service;

public interface ExchangeTradeService extends IService<ExchangeTrade> {

}

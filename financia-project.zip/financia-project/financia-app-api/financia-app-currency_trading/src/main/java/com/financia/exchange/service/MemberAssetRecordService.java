package com.financia.exchange.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.swap.MemberAssetRecord;

public interface MemberAssetRecordService extends IService<MemberAssetRecord> {
}

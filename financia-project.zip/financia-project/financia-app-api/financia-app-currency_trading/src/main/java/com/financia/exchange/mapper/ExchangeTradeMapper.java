package com.financia.exchange.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.trading.ExchangeTrade;

public interface ExchangeTradeMapper extends BaseMapper<ExchangeTrade> {
}

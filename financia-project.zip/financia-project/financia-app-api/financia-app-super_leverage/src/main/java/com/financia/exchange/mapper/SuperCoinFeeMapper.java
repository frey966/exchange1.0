package com.financia.exchange.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.superleverage.SuperCoinFee;

public interface SuperCoinFeeMapper extends BaseMapper<SuperCoinFee> {

}

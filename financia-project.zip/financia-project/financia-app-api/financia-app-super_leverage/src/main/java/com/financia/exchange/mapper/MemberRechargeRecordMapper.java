package com.financia.exchange.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.swap.MemberRechargeRecord;

/**
 * 合约交易币Mapper接口
 *
 * @author ruoyi
 * @date 2022-07-13
 */
public interface MemberRechargeRecordMapper extends BaseMapper<MemberRechargeRecord>
{

}

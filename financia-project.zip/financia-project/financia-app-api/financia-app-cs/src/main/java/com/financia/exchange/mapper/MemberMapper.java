package com.financia.exchange.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.financia.exchange.Member;


/**
 * 会员信息Mapper接口
 *
 * @author ruoyi
 * @date 2022-07-13
 */
public interface MemberMapper extends BaseMapper<Member>
{

}

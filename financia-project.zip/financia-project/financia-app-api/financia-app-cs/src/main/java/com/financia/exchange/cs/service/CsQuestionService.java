package com.financia.exchange.cs.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.financia.cs.CsQuestion;

/**
 * 客服-自动回复问题
 *
 * @author dalong
 * @email xxxxxx@qq.com
 * @date 2022-09-22 17:05:31
 */
public interface CsQuestionService extends IService<CsQuestion> {

//    PageUtils queryPage(Map<String, Object> params);
}


package redis.clients.jedis.commands.unified;

import redis.clients.jedis.UnifiedJedis;

public abstract class UnifiedJedisCommandsTestBase {

  protected static UnifiedJedis jedis;

  public UnifiedJedisCommandsTestBase() {
  }
}

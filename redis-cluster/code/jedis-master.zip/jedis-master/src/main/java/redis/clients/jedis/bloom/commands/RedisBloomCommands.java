package redis.clients.jedis.bloom.commands;

public interface RedisBloomCommands extends BloomFilterCommands, CuckooFilterCommands,
    CountMinSketchCommands, TopKFilterCommands, TDigestSketchCommands {

}

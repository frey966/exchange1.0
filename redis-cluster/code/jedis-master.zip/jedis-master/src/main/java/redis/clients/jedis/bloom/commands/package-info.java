/**
 * This package contains the interfaces that contain methods representing RedisBloom commands.
 */
package redis.clients.jedis.bloom.commands;

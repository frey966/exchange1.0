/**
 * This package contains the Exception classes.
 */
package redis.clients.jedis.exceptions;

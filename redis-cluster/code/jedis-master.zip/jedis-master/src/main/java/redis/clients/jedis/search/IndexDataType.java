package redis.clients.jedis.search;

public enum IndexDataType {
  HASH,
  JSON
}

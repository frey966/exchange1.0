/**
 * This package contains the utility classes.
 */
package redis.clients.jedis.util;

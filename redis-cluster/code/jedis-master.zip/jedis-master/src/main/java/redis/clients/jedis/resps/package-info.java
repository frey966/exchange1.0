/**
 * This package contains custom responses of core Redis commands.
 */
package redis.clients.jedis.resps;

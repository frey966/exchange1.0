/**
 * This package contains the implementations of ConnectionProvider interface.
 */
package redis.clients.jedis.providers;

/**
 * This package contains the classes that represent optional parameters of core Redis commands.
 */
package redis.clients.jedis.params;

/**
 * This package contains the implementations of CommandExecutor interface.
 */
package redis.clients.jedis.executors;
